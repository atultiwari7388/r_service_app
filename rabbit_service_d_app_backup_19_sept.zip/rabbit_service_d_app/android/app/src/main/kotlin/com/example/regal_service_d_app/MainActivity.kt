package com.rabbit_u_d_app.rabbit_services_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}