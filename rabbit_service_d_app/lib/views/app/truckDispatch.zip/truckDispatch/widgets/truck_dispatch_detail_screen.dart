import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:regal_service_d_app/utils/constants.dart';
import 'package:regal_service_d_app/views/app/truckDispatch/truck_disptach_screen.dart';
// NOTE: Add url_launcher to your pubspec.yaml
import 'package:url_launcher/url_launcher.dart';

class DispatchDetailsScreen extends StatefulWidget {
  final LoadData load;

  const DispatchDetailsScreen({super.key, required this.load});

  @override
  State<DispatchDetailsScreen> createState() => _DispatchDetailsScreenState();
}

class _DispatchDetailsScreenState extends State<DispatchDetailsScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 4, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  /// Opens the external map application (Google Maps or Apple Maps)
  Future<void> _openMap(String address) async {
    // 1. Create a platform-agnostic query
    final query = Uri.encodeComponent(address);

    // 2. Define the URLs for Google Maps and Apple Maps
    final googleMapsUrl =
        Uri.parse("https://www.google.com/maps/search/?api=1&query=$query");
    final appleMapsUrl = Uri.parse("https://maps.apple.com/?q=$query");

    try {
      // 3. Try to launch
      if (await canLaunchUrl(googleMapsUrl)) {
        await launchUrl(googleMapsUrl, mode: LaunchMode.externalApplication);
      } else if (await canLaunchUrl(appleMapsUrl)) {
        await launchUrl(appleMapsUrl, mode: LaunchMode.externalApplication);
      } else {
        // Fallback or error handling
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Could not open maps application')),
          );
        }
      }
    } catch (e) {
      debugPrint('Error launching map: $e');
    }
  }

  /// Helper to decide which address to navigate to based on load status
  void _handleNavigationPress() {
    // Logic: If active, maybe go to dropoff? For now, we default to Pickup
    // or we can show a selection dialog.
    // Let's create a combined string for accuracy.
    final fullAddress =
        "${widget.load.pickupAddress}, ${widget.load.pickupLocation}";
    _openMap(fullAddress);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Colors.white,
        leading: Container(
          margin: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: kLightWhite,
            borderRadius: BorderRadius.circular(12),
          ),
          child: IconButton(
            icon: const Icon(Icons.arrow_back_ios_new, size: 16, color: kDark),
            onPressed: () => Navigator.pop(context),
          ),
        ),
        title: const Text(
          'Load Details',
          style: TextStyle(
            fontWeight: FontWeight.w800,
            color: kDark,
            fontSize: 20,
          ),
        ),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(50),
          child: Container(
            decoration: BoxDecoration(
              border: Border(bottom: BorderSide(color: Colors.grey.shade100)),
            ),
            child: TabBar(
              controller: _tabController,
              labelColor: kPrimary,
              unselectedLabelColor: Colors.grey[500],
              indicatorColor: kPrimary,
              indicatorWeight: 3,
              labelStyle:
                  const TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
              unselectedLabelStyle:
                  const TextStyle(fontWeight: FontWeight.w600, fontSize: 14),
              tabs: const [
                Tab(text: 'Overview'),
                Tab(text: 'Docs'),
                Tab(text: 'Info'),
                Tab(text: 'Notes'),
              ],
            ),
          ),
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          _buildDetailsTab(),
          _buildDocumentsTab(),
          _buildLoadInfoTab(),
          _buildNotesTab(),
        ],
      ),
    );
  }

  // --- TABS ---

  Widget _buildDetailsTab() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header Card
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: kLightWhite,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: Colors.grey.shade100),
            ),
            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          widget.load.loadNumber,
                          style: const TextStyle(
                            fontSize: 22,
                            fontWeight: FontWeight.w800,
                            color: kDark,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Row(
                          children: [
                            const Icon(Icons.business,
                                size: 16, color: Colors.grey),
                            const SizedBox(width: 6),
                            Text(
                              widget.load.company,
                              style: TextStyle(
                                color: Colors.grey[600],
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                    _buildStatusChip(widget.load.status),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 24),

          Container(
            height: 180,
            width: double.infinity,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: Colors.grey.shade200),
            ),
            clipBehavior: Clip.hardEdge,
            child: Stack(
              children: [
                GoogleMap(
                  initialCameraPosition: CameraPosition(
                    target: LatLng(
                      34.0522,
                      -118.2437,
                    ),
                    zoom: 6,
                  ),
                  markers: {
                    Marker(
                      markerId: const MarkerId('pickup'),
                      position: LatLng(
                        34.0522,
                        -118.2437,
                      ),
                      icon: BitmapDescriptor.defaultMarkerWithHue(
                          BitmapDescriptor.hueRed),
                    ),
                    Marker(
                      markerId: const MarkerId('drop'),
                      position: LatLng(
                        34.0522,
                        -118.2437,
                      ),
                      icon: BitmapDescriptor.defaultMarkerWithHue(
                          BitmapDescriptor.hueBlue),
                    ),
                  },

                  // 🔒 Disable interactions (static preview feel)
                  zoomGesturesEnabled: false,
                  scrollGesturesEnabled: false,
                  rotateGesturesEnabled: false,
                  tiltGesturesEnabled: false,
                  zoomControlsEnabled: false,
                  myLocationButtonEnabled: false,
                  mapToolbarEnabled: false,
                  compassEnabled: false,

                  // Optional: dark map style if you want
                  // onMapCreated: (controller) {
                  //   controller.setMapStyle(darkMapStyle);
                  // },
                ),

                // 🔘 Open Navigation Button
                Center(
                  child: ElevatedButton.icon(
                    onPressed: _handleNavigationPress,
                    icon: const Icon(Icons.map, size: 18),
                    label: const Text('Open Navigation'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: kDark,
                      foregroundColor: Colors.white,
                      elevation: 0,
                      padding: const EdgeInsets.symmetric(
                          horizontal: 20, vertical: 12),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(30),
                      ),
                    ),
                  ),
                ),

                // 🚗 Distance / Time chip
                Positioned(
                  bottom: 16,
                  right: 16,
                  child: Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(20),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.1),
                          blurRadius: 10,
                        ),
                      ],
                    ),
                    child: Row(
                      children: [
                        const Icon(Icons.speed, size: 16, color: kPrimary),
                        const SizedBox(width: 6),
                        Text(
                          '${widget.load.miles} • ~14h 20m',
                          style: const TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 12,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),

          // Route Timeline
          const Text(
            'Routes',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: kDark,
            ),
          ),
          const SizedBox(height: 16),
          IntrinsicHeight(
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Column(
                  children: [
                    const Icon(Icons.circle, size: 16, color: kPrimary),
                    Expanded(
                      child: Container(
                        width: 2,
                        color: Colors.grey.shade200,
                        margin: const EdgeInsets.symmetric(vertical: 4),
                      ),
                    ),
                    const Icon(Icons.location_on, size: 20, color: Colors.red),
                  ],
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _buildTimelineItem(
                        title: 'PICKUP',
                        building: widget.load.pickupBuilding,
                        address: widget.load.pickupAddress,
                        location: widget.load.pickupLocation,
                        date: widget.load.pickupDate,
                        isStart: true,
                        // Allow clicking specific addresses to navigate
                        onTap: () => _openMap(
                            "${widget.load.pickupAddress}, ${widget.load.pickupLocation}"),
                      ),
                      const SizedBox(height: 30),
                      _buildTimelineItem(
                        title: 'DROP-OFF',
                        building: widget.load.dropBuilding,
                        address: widget.load.dropAddress,
                        location: widget.load.dropLocation,
                        date: widget.load.dropDate,
                        isStart: false,
                        // Allow clicking specific addresses to navigate
                        onTap: () => _openMap(
                            "${widget.load.dropAddress}, ${widget.load.dropLocation}"),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),

          const SizedBox(height: 30),
          const Divider(),
          const SizedBox(height: 20),

          // Contact
          const Text(
            'Contact Information',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: kDark,
            ),
          ),
          const SizedBox(height: 16),
          _buildContactTile(
              Icons.person_outline, 'Broker Contact', 'Michael Scott'),
          const SizedBox(height: 12),
          _buildContactTile(
              Icons.phone_outlined, 'Phone Number', '+1 (555) 019-2834'),
        ],
      ),
    );
  }

  Widget _buildDocumentsTab() {
    final docs = [
      {'name': 'Rate Confirmation', 'type': 'PDF', 'size': '1.2 MB'},
      {'name': 'Bill of Lading', 'type': 'PDF', 'size': '2.4 MB'},
      {'name': 'Insurance Cert', 'type': 'JPG', 'size': '3.1 MB'},
    ];

    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        Container(
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
              color: kLightWhite,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(
                  color: Colors.grey.shade200, style: BorderStyle.none),
              boxShadow: [
                BoxShadow(
                  color: Colors.grey.withOpacity(0.05),
                  blurRadius: 10,
                  offset: const Offset(0, 4),
                )
              ]),
          child: Column(
            children: [
              const Icon(Icons.cloud_upload_outlined,
                  size: 48, color: kPrimary),
              const SizedBox(height: 16),
              const Text(
                'Upload POD or Receipts',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
              ),
              const SizedBox(height: 8),
              Text(
                'Supports PDF, JPG, PNG',
                style: TextStyle(color: Colors.grey[500], fontSize: 12),
              ),
              const SizedBox(height: 16),
              OutlinedButton(
                onPressed: () {},
                style: OutlinedButton.styleFrom(
                  foregroundColor: kPrimary,
                  side: const BorderSide(color: kPrimary),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10)),
                ),
                child: const Text('Browse Files'),
              ),
            ],
          ),
        ),
        const SizedBox(height: 24),
        const Text(
          'Attached Files',
          style: TextStyle(
              fontSize: 18, fontWeight: FontWeight.bold, color: kDark),
        ),
        const SizedBox(height: 16),
        ...docs.map((d) => Container(
              margin: const EdgeInsets.only(bottom: 12),
              decoration: BoxDecoration(
                border: Border.all(color: Colors.grey.shade200),
                borderRadius: BorderRadius.circular(16),
              ),
              child: ListTile(
                leading: Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: Colors.red.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: const Icon(Icons.picture_as_pdf,
                      color: Colors.red, size: 20),
                ),
                title: Text(d['name']!,
                    style: const TextStyle(fontWeight: FontWeight.bold)),
                subtitle: Text('${d['type']} • ${d['size']}'),
                trailing: IconButton(
                  icon: const Icon(Icons.download_rounded, color: kPrimary),
                  onPressed: () {},
                ),
              ),
            )),
      ],
    );
  }

  Widget _buildLoadInfoTab() {
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        _buildInfoSection('Load Specs', [
          {'label': 'Weight', 'value': '42,500 lbs'},
          {'label': 'Commodity', 'value': 'General Freight'},
          {'label': 'Type', 'value': 'Full Truckload (FTL)'},
          {'label': 'Temp', 'value': 'Dry Van'},
        ]),
        const SizedBox(height: 20),
        _buildInfoSection('Equipment', [
          {'label': 'Truck ID', 'value': 'TRK-8821'},
          {'label': 'Trailer ID', 'value': 'TRL-5502'},
          {'label': 'Driver', 'value': 'James Anderson'},
        ]),
        const SizedBox(height: 20),
        _buildInfoSection('Financials', [
          {'label': 'Rate', 'value': '\$2,450.00'},
          {'label': 'Detention', 'value': '\$50/hr'},
          {'label': 'Lumper', 'value': 'Reimbursed'},
        ]),
      ],
    );
  }

  Widget _buildNotesTab() {
    return Stack(
      children: [
        ListView(
          padding: const EdgeInsets.all(20),
          children: [
            _buildNoteItem(
              'Gate Code',
              'The gate code for entry is #9921. Please call security if it does not work.',
              'Today, 9:00 AM',
            ),
            _buildNoteItem(
              'Handling Inst.',
              'Fragile contents. Do not double stack pallets.',
              'Yesterday',
            ),
          ],
        ),
        Positioned(
          bottom: 20,
          left: 20,
          right: 20,
          child: ElevatedButton(
            onPressed: () {},
            style: ElevatedButton.styleFrom(
              backgroundColor: kDark,
              foregroundColor: Colors.white,
              padding: const EdgeInsets.symmetric(vertical: 16),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16),
              ),
            ),
            child: const Text('Add New Note'),
          ),
        ),
      ],
    );
  }

  // --- HELPERS ---

  Widget _buildStatusChip(String status) {
    Color color;
    switch (status.toLowerCase()) {
      case 'active':
        color = kPrimary;
        break;
      case 'completed':
        color = Colors.green;
        break;
      default:
        color = Colors.orange;
    }
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(
        status.toUpperCase(),
        style: TextStyle(
          color: color,
          fontWeight: FontWeight.bold,
          fontSize: 12,
        ),
      ),
    );
  }

  Widget _buildTimelineItem({
    required String title,
    required String building,
    required String address,
    required String location,
    required String date,
    required bool isStart,
    required VoidCallback onTap, // Added callback
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Container(
        padding: const EdgeInsets.all(8),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Text(
                  title,
                  style: TextStyle(
                    color: Colors.grey[500],
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 1,
                  ),
                ),
                const Spacer(),
                const Icon(Icons.navigation,
                    size: 14, color: kPrimary), // Visual cue
              ],
            ),
            const SizedBox(height: 4),
            Text(
              building,
              style: const TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w700,
                color: kDark,
              ),
            ),
            const SizedBox(height: 2),
            Text(
              address,
              style: TextStyle(color: Colors.grey[600], fontSize: 14),
            ),
            Text(
              location,
              style: TextStyle(color: Colors.grey[600], fontSize: 14),
            ),
            const SizedBox(height: 8),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(
                color: isStart
                    ? kPrimary.withOpacity(0.1)
                    : Colors.red.withOpacity(0.1),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text(
                date,
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                  color: isStart ? kPrimary : Colors.red,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildContactTile(IconData icon, String title, String subtitle) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.grey.shade200),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: kLightWhite,
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(icon, color: kDark, size: 20),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title,
                    style: TextStyle(color: Colors.grey[500], fontSize: 12)),
                Text(subtitle,
                    style: const TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 15,
                        color: kDark)),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: Colors.green.withOpacity(0.1),
              borderRadius: BorderRadius.circular(8),
            ),
            child: const Icon(Icons.phone, color: Colors.green, size: 18),
          ),
        ],
      ),
    );
  }

  Widget _buildInfoSection(String title, List<Map<String, String>> items) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(title,
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),
        Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: Colors.grey.shade200),
          ),
          child: Column(
            children: items.asMap().entries.map((entry) {
              final idx = entry.key;
              final item = entry.value;
              return Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.all(16),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(item['label']!,
                            style: TextStyle(color: Colors.grey[600])),
                        Text(item['value']!,
                            style:
                                const TextStyle(fontWeight: FontWeight.bold)),
                      ],
                    ),
                  ),
                  if (idx != items.length - 1)
                    Divider(height: 1, color: Colors.grey.shade100),
                ],
              );
            }).toList(),
          ),
        ),
      ],
    );
  }

  Widget _buildNoteItem(String title, String content, String time) {
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFFFFFBEB), // Light yellow note feel
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFFFEF3C7)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(title,
                  style: const TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                      color: Color(0xFF92400E))),
              Text(time,
                  style:
                      const TextStyle(fontSize: 12, color: Color(0xFFB45309))),
            ],
          ),
          const SizedBox(height: 8),
          Text(content,
              style: const TextStyle(color: Color(0xFF92400E), height: 1.5)),
        ],
      ),
    );
  }
}
